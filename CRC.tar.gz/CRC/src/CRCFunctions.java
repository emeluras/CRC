public class CRCFunctions {

	// Application of long division
	// returns remainder
	public String longDivision(String M, String G) {

		long g_x = Long.parseLong(G, 2);
		int gLenght = G.length();
		int i = 0;

		while (M.length() >= G.length()) {

			if (M.charAt(i) == '1') {

				String Mpart = M.substring(0, gLenght);
				String Mrest = M.substring(gLenght);

//				long m_x = Long.parseLong(Mpart, 2);

				
				String sXOR = XOR(Mpart, G);
//				LONG P_X = M_X ^ G_X;
//				String sXOR = Long.toBinaryString(p_x);
				while (sXOR.length() < gLenght - 1) {
					sXOR = "0" + sXOR;
				}
				M = sXOR + Mrest;
			} else {

				M = M.substring(1);
			}
		}
		return M;
	}

	public static String XOR(String M, String R) {

		int lenghtM = M.length();
		int lenghtR = R.length();
		String xor = "";

		while (lenghtM != lenghtR) {
			if (lenghtM < lenghtR) {
				M = "0" + M;
				lenghtM = M.length();
			} else {
				R = "0" + R;
				lenghtR = R.length();
			}
		}

		for (int i = 0; i < lenghtM; i++) {
			char m = M.charAt(i);
			char r = R.charAt(i);
			if (m == r) {
				xor += "0";
			}else{
				xor += "1";
			}
		}
		return xor;
	}

	public String findTransmittedMessage(String M, String G) {

		String M_prime = M;

		// degree of reference
		int degree = G.length() - 1;
		// pad message
		for (int i = 0; i < degree; i++) {
			M_prime += "0";
		}

		// find remainder of M'(x)/G(x)
//		long m_prime_x = Long.parseLong(M_prime, 2);
		String remainder = longDivision(M_prime, G);

		// pad message with zeros
		if (remainder.length() < G.length() - 1) {
			remainder = "0" + remainder;
		}

//		System.out.println("Remainder: R(x)= " + remainder);
//		long r_x = Long.parseLong(remainder, 2);

//		// P(x) = M'(x) - R(x)
//		long p_x = m_prime_x ^ r_x;
		
//		String transmittedMessage = Long.toBinaryString(p_x);
		String transmittedMessage = XOR(M_prime, remainder);
		
		return transmittedMessage;
	}

}
