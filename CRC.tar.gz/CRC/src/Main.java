import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Random;



public class Main {
	
	
	

	public static void main(String[] args) {
		
		String CRC32_g_X = "100000100110000010001110110110111";

		///!!! G(x) is defined here, not take from user !!!!
		String reference = "1101";
		String message = "";
		System.out.println("Enter message M(x): ");

		try {
			BufferedReader bufferRead = new BufferedReader(
					new InputStreamReader(System.in));
			message = bufferRead.readLine();

			System.out.println(message);
		} catch (IOException e) {
			e.printStackTrace();
		}

		CRCFunctions ftd = new CRCFunctions();
		System.out.println("____________Assignment#2 - Q3 -c) - a)  __________\n");
		String transmittedMessage = ftd.findTransmittedMessage(message,reference);
		System.out.println("Ref. No. : G(x) = " + reference
				+ "\nMessage: M(x) = " + message
				+ "\nTransmitted Message: P(x) = " + transmittedMessage + "\n");
		
		
		
		System.out.println("____________Assignment#2 - Q3 -c) - b)  __________\n");		
		System.out.println("Enter a bit string with CRC remainder appended: \n");
		String msg = "";
		try {
			BufferedReader bufferRead = new BufferedReader(
					new InputStreamReader(System.in));
			msg = bufferRead.readLine();

			System.out.println(msg);
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		String remainder = ftd.longDivision(msg, reference);
		long remainderLong = Long.parseLong(remainder, 2);
		if(remainderLong == 0){
			System.out.println("There is no error.");
						
		}
		else {
			System.out.println("There is an error! - Remainder:" + remainder);
		}
		
		
		// CRC-32
		System.out.println("____________Assignment#2 - Q3 -c) - d)  __________\n");		
		
		CRC32 crc32 = new CRC32();
		System.out.println("The experiment started!");
		String result = crc32.findNumberOfErrorDetection(CRC32_g_X);
		System.out.println(result);
	}
}
