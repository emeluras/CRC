import java.util.Random;

public class CRC32 {

	static CRCFunctions crc = new CRCFunctions();

	public static String generateMessage() {

		// 1520 byte = 1520*8 bits =12160 bits
		String m_x = "";

		// generated a random number in the interval 0-1
		// if the generated number < 0.5 bit is 0, otherwise 1.
		int min = 0;
		int max = 1;
		Random rand = new Random();
		for (int i = 0; i < 12160; i++) {

			int randomNum = rand.nextInt((max - min) + 1) + min;
			if (randomNum < 0.5) {
				m_x += "0";
			} else {
				m_x += "1";
			}
		}
		return m_x;

	}

	public static String introduceRandomBurstError(String m_x, String g_x,
			int burstErrorLength) {

		String p_x = crc.findTransmittedMessage(m_x, g_x);
//		System.out.println("lenght of p_x " + p_x.length());
		int min = 0;
		int max = 12191; // 1524 byte-lenght of p(x)
		Random rand = new Random();
		for (int i = 0; i < burstErrorLength; i++) {
			
			
			// in order to introduce burst error, changes 0 to 1 or 1 to zero in
			// randomly selected index
			int randomNum = rand.nextInt((max - min) + 1) + min;
			char c = p_x.charAt(randomNum);
			if (c == '0') {
				String first = p_x.substring(0, i);
				String second = p_x.substring(i + 1, p_x.length());
				p_x = first + "1" + second;
			} else {
				String first = p_x.substring(0, i);
				String second = p_x.substring(i + 1, p_x.length());
				p_x = first + "0" + second;
			}

		}

		return p_x;

	}

	public static String findNumberOfErrorDetection(String g_x) {

		String m_x = "";
		String p_x_withBurstError = "";
		String remainder = "";
		long rmd = 0;
		Random rand = new Random();
		int min = 0;
		int max = 100; // 100 max burst error lenght
		int smallerThan32 = 0;
		int equalTo32 = 0;
		int biggerThan32 = 0;
		int detectionForSmallerThan32 = 0;
		int detectionForEqualTo32 = 0;
		int detectionForBiggerThan32 = 0;
		int a=1;
		int b = 0;

		for (int i = 0; i < 1000; i++) {
			a++;

			int burstErrorLength = rand.nextInt((max - min) + 1) + min;

			m_x = generateMessage();
			p_x_withBurstError = introduceRandomBurstError(m_x, g_x,
					burstErrorLength);

			remainder = crc.longDivision(p_x_withBurstError, g_x);
			rmd = Long.parseLong(remainder, 2);

			if (rmd != 0) {
				if (burstErrorLength < 32) {
					smallerThan32++;
					detectionForSmallerThan32++;

				} else if (burstErrorLength > 32) {
					biggerThan32++;
					detectionForBiggerThan32++;

				} else {
					equalTo32++;
					detectionForEqualTo32++;
				}

			} else {
				if (burstErrorLength < 32) {
					smallerThan32++;

				} else if (burstErrorLength > 32) {
					biggerThan32++;

				} else {
					equalTo32++;
				}
			}
			
			if(a == 100 ){
				b = b+100;
				System.out.println("The " +b + ". iteration is comlpeted.");
				a=0;
			}

		}
		String result = "Burst error length > 32: " + smallerThan32
				+ " Number  of  frames-error was detected: "
				+ detectionForSmallerThan32 + "\nBurst error length = 32: "
				+ equalTo32 + " Number  of  frames-error was detected: "
				+ detectionForEqualTo32 + "\nBurst error length < 32: "
				+ biggerThan32 + " Number  of  frames-error was detected: "
				+ detectionForBiggerThan32;
		return result;
	}

}
